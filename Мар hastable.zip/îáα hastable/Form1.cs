﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;

namespace Мар_hastable
{
    public partial class Form1 : Form
    {
        Hashtable surname = new Hashtable();
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            bool temp = true;
            bool temp1 = true;
            if (textBox2.Text.Length != 11)
            {
                MessageBox.Show("введите верную длину номера телефона, 11 цифр");
            }
            else if (!(textBox1.Text == "") && !(textBox2.Text == "") && !surname.ContainsKey(textBox1.Text) && !surname.ContainsValue(textBox2.Text))
            {
                for (int i = 0; i < textBox1.Text.Length; i++)
                {
                    if (!char.IsLetter(textBox1.Text[i]))
                    {
                        temp = false;
                        break;
                    }
                }
                for (int i = 0; i < textBox2.Text.Length; i++)
                {
                    if (!char.IsNumber(textBox2.Text[i]))
                    {
                        temp1 = false;
                        break;
                    }
                }
                if (temp == true && temp1 == true)
                {
                    surname.Add(textBox1.Text, textBox2.Text);
                    listBox1.Items.Add($"Фамилия {textBox1.Text}, Номер {textBox2.Text}");
                }
            }

        }
    


    

        private void button2_Click(object sender, EventArgs e)
        {
            if (!(textBox4.Text == ""))
            {
                foreach (string elements in surname.Keys)
                {
                    if (elements == textBox4.Text)
                    {
                        listBox2.Items.Add("Фамилия " + elements + " " + "Номер " + surname[elements].ToString());
                    }
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (!(textBox3.Text == ""))
            {
                foreach (string elements in surname.Keys)
                {
                    if (surname[elements].ToString() == textBox3.Text)
                    {
                        listBox2.Items.Add("Фамилия " + elements + " " + "Номер " + surname[elements].ToString());
                    }
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (listBox2.Items.Count > 0)
            {
                foreach (string elements in surname.Keys)
                {
                    if (elements == textBox4.Text)
                    {
                        for (int i = 0; i < listBox2.Items.Count; i++)
                        {
                            if (Convert.ToString(listBox2.Items[i]).Contains(elements))
                            {
                                listBox2.Items.Remove(Convert.ToString(listBox2.Items[i]));
                                i--;
                            }
                        }
                    }
                }
            }

        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (listBox2.Items.Count > 0)
            {
                foreach (string elements in surname.Keys)
                {
                    if (surname[elements].ToString() == textBox3.Text)
                    {
                        for (int i = 0; i < listBox2.Items.Count; i++)
                        {
                            if (Convert.ToString(listBox2.Items[i]).Contains(elements))
                            {
                                listBox2.Items.Remove(Convert.ToString(listBox2.Items[i]));
                                i--;
                            }
                        }
                    }
                }
            }

        }

        private void button6_Click(object sender, EventArgs e)
        {

            listBox1.Items.Clear();
            listBox2.Items.Clear();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (!(listBox1.SelectedIndex == -1))
            {
                int select = listBox1.SelectedIndex;
                listBox1.Items.RemoveAt(select);
                textBox1.Text = "";
                textBox2.Text = "";
            }
        }
    }
}

    

